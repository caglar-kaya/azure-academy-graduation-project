import csv
from sortedcontainers import SortedKeyList


def write_transactions_to_csv(transactions_list: list, csv_file_path_and_name = "part_r_00000_CNA.csv") -> None:
    if len(transactions_list) < 1:
        print("No transactions to write")
        return

    transactions = SortedKeyList(key=lambda obj1: obj1.bookg_dt_tm_gmt)
    for transactions_per_cust in transactions_list:
        for transaction in transactions_per_cust:
            transactions.add(transaction)

    print(f"There are {len(transactions)} transactions in total")
    columns = [attr for attr in dir(transactions[0]) if not callable(getattr(transactions[0], attr)) and not attr.startswith("__")]

    # Write to CSV
    with open(csv_file_path_and_name, 'w', newline='', encoding='utf-8') as csvfile:
        csv_writer = csv.writer(csvfile)

        # Write the header
        csv_writer.writerow(columns)

        for obj in transactions:
            row = [getattr(obj, col) for col in columns]
            csv_writer.writerow(row)

    print(f"CSV file '{csv_file_path_and_name}' has been created.")
