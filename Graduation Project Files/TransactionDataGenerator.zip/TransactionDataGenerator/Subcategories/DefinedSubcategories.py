from Subcategories.Geldmaat import Geldmaat
from Subcategories.Ontvangen import Ontvangen
from Subcategories.Overschrijving import Overschrijving
from Subcategories.Tikkie import Tikkie


geldmaat = Geldmaat()
overschrijving = Overschrijving()
ontvangen = Ontvangen()
tikkie = Tikkie()


sub_cats = {
    2222: [(0.95, geldmaat), (0.05, overschrijving)],
    5411: [(1, overschrijving)],
    5420: [(1, overschrijving)],
    5462: [(1, overschrijving)],
    5422: [(1, overschrijving)],
    5912: [(1, overschrijving)],
    4131: [(1, overschrijving)],
    4111: [(1, overschrijving)],
    4112: [(1, overschrijving)],
    5541: [(1, overschrijving)],
    5542: [(1, overschrijving)],
    4511: [(1, overschrijving)],
    7512: [(1, overschrijving)],
    4121: [(1, overschrijving)],
    6542: [(1, overschrijving)],
    6630: [(1, overschrijving)],
    3333: [(1, tikkie)],
    1111: [(1, ontvangen)],
}
