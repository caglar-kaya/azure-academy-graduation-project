import Variables
from Customer import generate_random_batch_customers
from TransactionGenerator import generate_transactions
from csv_writer import write_transactions_to_csv


def create_transactions_csv():
    random_customers = generate_random_batch_customers(Variables.number_of_customers)
    transactions = generate_transactions(Variables.start_time, Variables.end_time, random_customers)

    print("\n\n")
    for i in random_customers[:10]:
        print(i.Client)
    print("\n\n")
    write_transactions_to_csv(transactions, Variables.csv_output_path)


if __name__ == "__main__":
    create_transactions_csv()
