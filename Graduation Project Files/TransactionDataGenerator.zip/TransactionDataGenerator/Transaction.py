from datetime import datetime
import RandomDataGenerator
import Variables
from Categories import Category
from Client import Client
from RandomDataGenerator import generate_random_8_4_4_4_12


def get_year_month(timestamp) -> str:
    return f"{timestamp.year}{timestamp.month if timestamp.month > 9 else '0' + str(timestamp.month)}"


class Transaction():
    def __init__(self, client: Client, counter_party: Client, tran_count: int, transaction_type: str, category_: Category,
                 booking_amount: float, crdt_dbt_indic: str, timestamp: datetime, timestamp_cet: datetime, balance_after_booking: float,
                 booking_id):
        self.acct_id = client.IBAN
        self.acct_ccy = client.Currency.value[0]
        self.ntry_seq_nb = tran_count
        self.bookg_amt = booking_amount
        self.bookg_amt_nmrc = int(booking_amount * 100)
        self.bookg_cdt_dbt_ind = crdt_dbt_indic
        self.bookg_dt_tm_gmt = timestamp
        self.bookg_dt_tm_cet = timestamp_cet
        self.year_month = get_year_month(timestamp)
        self.bal_aftr_bookg = balance_after_booking
        self.bal_aftr_bookg_nmrc = int(balance_after_booking * 100)
        self.tx_tp = transaction_type
        self.dtld_tx_tp = category_.dtld_tx_tp
        self.ctpty_nm = counter_party.Name
        self.ctpty_ctry = counter_party.Country
        self.ctpty_adr_line1 = counter_party.Address
        self.ctpty_adr_line2 = None

        self.rmt_inf_ustrd1 = category_.sub_type.generate_description(counter_party)
        self.rmt_inf_ustrd2 = None

        self.booking_id = booking_id

        self.end_to_end_id = generate_random_8_4_4_4_12()
        self.tx_acct_svcr_ref = generate_random_8_4_4_4_12()
        if category_.sub_type.agt_bic:
            self.cdtr_schme_id = None
            self.card_poi_id = None
            self.ctpty_agt_bic = RandomDataGenerator.generate_random_string_letters()
            self.ctpty_acct_id_iban = Variables.tikkie_iban if category_.dtld_tx_tp == 3333 else counter_party.IBAN
            self.ctpty_acct_id_bban = Variables.tikkie_bban if category_.dtld_tx_tp == 3333 else counter_party.BBAN
            self.ctpty_acct_ccy = counter_party.Currency.value[0]
        else:  # geldmaat
            self.cdtr_schme_id = generate_random_8_4_4_4_12()
            self.card_poi_id = client.card_poi_id  # using generate_random_8_4_4_4_12()
            self.ctpty_agt_bic = None
            self.ctpty_acct_id_iban = None
            self.ctpty_acct_id_bban = None
            self.ctpty_acct_ccy = None
            self.ctpty_nm = Variables.geldmaat_ctpty_name

    def update_balance(self, balance) -> None:
        self.bal_aftr_bookg = balance
        self.bal_aftr_bookg_nmrc = int(balance * 100)
