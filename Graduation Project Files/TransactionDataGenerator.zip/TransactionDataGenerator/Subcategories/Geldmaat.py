import RandomDataGenerator
from Client import Client
from Subcategories.SubCategory import SubCategory


class Geldmaat(SubCategory):
    name = "Geldmaat"
    agt_bic = False

    def generate_description(self, counterParty: Client) -> str:
        return f"{self.name}: {RandomDataGenerator.generate_random_8_4_4_4_12()}"