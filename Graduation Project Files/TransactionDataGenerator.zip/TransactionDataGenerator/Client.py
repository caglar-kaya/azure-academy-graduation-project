import Bank
import RandomDataGenerator
import Variables


class Client():
    def __init__(self, name: str, country: str, iban: str, bban: str, card_poi_id: str, currency: Variables.Currency, address: str):
        self.Name = name
        self.Country = country
        self.IBAN = iban
        self.BBAN = bban
        self.card_poi_id = card_poi_id
        self.Currency = currency
        self.Address = address

    @classmethod
    def create_random_client(cls, bank: Bank.Bank = None, company: bool = False):
        # Generate random values for properties
        iban, currency = RandomDataGenerator.generate_random_iban(bank)
        bban = iban[8:11] + "." + iban[11:13] + "." + iban[13:15] + "." + iban[15:]
        card_poi_id = RandomDataGenerator.generate_random_8_4_4_4_12()
        address, country, name = RandomDataGenerator.generate_address_and_country_and_name(currency, company=company)
        return cls(name, country, iban, bban, card_poi_id, currency, address)

    def __str__(self):
        return f"{self.Name} living at {self.Address} ({self.Country}). IBAN: {self.IBAN} ({self.BBAN}) with id: {self.card_poi_id}, using {self.Currency.value[0]}"
