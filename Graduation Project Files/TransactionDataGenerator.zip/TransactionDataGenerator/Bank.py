from Currency import Currency


class Bank():
    def __init__(self, iban_start: str, currency: Currency):
        self.__IBAN_start = iban_start
        self.__Currency = currency

    def get_iban_start(self) -> str:
        return self.__IBAN_start

    def get_bank_currency(self) -> Currency:
        return self.__Currency
