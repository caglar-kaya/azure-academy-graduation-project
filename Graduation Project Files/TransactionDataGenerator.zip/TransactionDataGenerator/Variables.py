from datetime import datetime

from faker import Faker
from Bank import Bank
import numpy as np
from collections import defaultdict

from Currency import Currency

# Clients per category can give more diverse counterparties
clients_per_category = 50  # see Categories.py
csv_output_path = "part_r_00000_CNA.csv"
number_of_customers = 250
start_time = datetime(2013, 1, 1, 0, 0, 0)
end_time = datetime(2015, 12, 31, 23, 59, 59)

# 2 years with 100 customers gives roughly 40000 transactions

tikkie_iban = "NL00TIKK1111111111"
tikkie_bban = "111.11.11.111"
geldmaat_ctpty_name = "Geldmaat ATM"


main_bank = Bank("NL12FAKE", Currency.EUR)
banks = [
    main_bank,
    Bank("NL05YEPP", Currency.EUR),
    Bank("NL98BOER", Currency.EUR),
    Bank("GB37FAKE", Currency.GBP),
    Bank("GB45SCAM", Currency.GBP),
    Bank("CA81VANC", Currency.CAD),
    Bank("US19PONZ", Currency.USD),
    Bank("JP77NISE", Currency.JPY)
]

iban_start_probabilities = [0.35, 0.24, 0.17, 0.05, 0.06, 0.06, 0.05, 0.02]
#iban_start_probabilities = [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.93]

uuid_faker = Faker()


# Randomly select a bank
def select_random_bank():
    return np.random.choice(banks, p=iban_start_probabilities)


# Randomly select an IBAN start
def get_iban_start():
    return np.random.choice(banks, p=iban_start_probabilities).get_iban_start()


currency_to_locale_dict = defaultdict(lambda: "nl_NL")
currency_to_locale_dict[Currency.GBP] = "en_GB"
currency_to_locale_dict[Currency.CAD] = "en_CA"
currency_to_locale_dict[Currency.USD] = "en_US"
currency_to_locale_dict[Currency.JPY] = "ja_JP"

currency_to_country = defaultdict(lambda: "NL")
currency_to_country[Currency.GBP] = "Great Britain"
currency_to_country[Currency.CAD] = "Canada"
currency_to_country[Currency.USD] = "United States"
currency_to_country[Currency.JPY] = "Japan"

additional_EURO_countries_and_faker = [
    ("Denmark", Faker("da_DK")), ("Germany", Faker("de_DE")), ("Austria", Faker("de_AT")), ("Spain", Faker("es_ES")),
    ("France", Faker("fr_FR")), ("Italy", Faker("it_IT")), ("Hungary", Faker("hu_HU")), ("Belgium", Faker("nl_BE"))
]


__locale_dict = {}
def get_faker_from_locale(locale: str):
    if locale not in __locale_dict:
        __locale_dict[locale] = Faker(locale)
    return __locale_dict[locale]


emission_dict = {5541: 1398.0, 5542: 1398.0, 4511: 1669.0, 7512: 235.0, 5912: 106.0, 4131: 557.0, 4111: 557.0,
                 4112: 163.0, 5411: 430.0, 5420: 150.0, 5462: 150.0, 5422: 430.0, 4121: 96.0, 6542: 423.0,
                 6630: 2534.0, 3333: 234.0, 2222: 234.0, 1111: 234.0}
