from Client import Client
from Subcategories.SubCategory import SubCategory


class Ontvangen(SubCategory):
    name = "Ontvangen"

    def generate_description(self, counterParty: Client) -> str:
        return f"{self.name}: {counterParty.Name}"
