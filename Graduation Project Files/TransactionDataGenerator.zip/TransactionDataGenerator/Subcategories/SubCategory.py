import abc

from Client import Client


class SubCategory(metaclass=abc.ABCMeta):
    agt_bic = True

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'generate_description') and
                callable(subclass.generate_description) or
                NotImplemented)

    @abc.abstractmethod
    def generate_description(self, counterParty: Client) -> str:
        raise NotImplementedError

