import calendar
import random
import uuid
from datetime import datetime, timedelta
from sortedcontainers import SortedKeyList
from dateutil import relativedelta

import Categories
from Customer import Customer
import numpy as np

from Transaction import Transaction


def generate_transactions(start_time: datetime, end_time: datetime, customers: list) -> list:
    all_transactions = []
    trans_counter = 1
    for customer in customers:
        sorted_trans, trans_counter = __generate_transactions_for_customer(customer, start_time, end_time, trans_counter)
        all_transactions.append(sorted_trans)
    return all_transactions


def __generate_transactions_for_customer(customer: Customer, start_time, end_time, trans_counter: int) -> (list, int):
    transactions = SortedKeyList(key=lambda obj: obj.bookg_dt_tm_gmt)
    months = __compute_time_diff(start_time, end_time)

    to_spend_monthly = (customer.Income - customer.Housing_cost) * customer.Spend_ratio + 10
    for m in range(0, months):
        curr_month = start_time + relativedelta.relativedelta(months=1)

        if customer.Income > 0:
            timess = datetime(curr_month.year, curr_month.month, customer.Payday, 9, 0, random.randint(0, 59))
            category = Categories.current_categories[-1]
            tr = Transaction(customer.Client, customer.Employer, trans_counter, "", category, customer.Income,
                             category.crdt_dbt, timess, timess, -1, uuid.uuid4())
            transactions.add(tr)
            trans_counter += 1  # Update the transaction counter

        spend_this_month = np.random.normal(to_spend_monthly, to_spend_monthly*0.1)
        sum_spending = 0
        while sum_spending < spend_this_month:
            timestamp = __generate_random_date(curr_month)

            transaction = __generate_new_transaction(sum_spending, customer, spend_this_month, timestamp, trans_counter)
            trans_counter += 1
            if transaction is not None:
                transactions.add(transaction)
                sum_spending += transaction.bookg_amt

    # fix the balance
    balance = customer.Original_balance
    for transaction in transactions:
        if transaction.bookg_cdt_dbt_ind == "CRDT":
            balance += transaction.bookg_amt
        else:
            balance -= transaction.bookg_amt
        transaction.update_balance(balance)
    return transactions, trans_counter


def __generate_random_date(offset: datetime):
    day = random.randint(1, calendar.monthrange(offset.year, offset.month)[1])  # Adjust for the maximum number of days in the month
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)
    second = random.randint(0, 59)
    return offset + timedelta(days=day, hours=hour, minutes=minute, seconds=second)


def __generate_new_transaction(sum_spending: float, customer: Customer, spend_this_month: float, times: datetime,
                               trans_counter: int) -> Transaction:
    category = random.choice(Categories.current_categories)
    amount = category.generate_amount(customer.Age_group)
    if amount < 0.5:
        return None
    if sum_spending + customer.Balance > spend_this_month:
        if np.random.rand() >= (spend_this_month - sum_spending) / amount:
            return None

    # Create transaction
    tr = Transaction(customer.Client, np.random.choice(category.clients), trans_counter, "", category, amount,
                     category.crdt_dbt, times, times, -1, uuid.uuid4())
    customer.add_transaction(tr)
    return tr


def __compute_time_diff(start_time: datetime, end_time: datetime) -> int:
    delta = relativedelta.relativedelta(end_time, start_time)

    # Calculate the number of months and round up
    months = delta.years * 12 + delta.months
    if delta.days > 0:
        months += 1
    return months

