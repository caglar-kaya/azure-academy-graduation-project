import random
import string
import numpy as np
from faker import Faker

import Variables


def generate_random_iban(bank: Variables.Bank = None) -> (str, Variables.Currency):
    bank = Variables.select_random_bank() if bank is None else bank
    iban_digits = str(random.randint(1, 9)) + ''.join(random.choice(string.digits) for _ in range(9))
    return bank.get_iban_start() + iban_digits, bank.get_bank_currency()


def generate_address_and_country_and_name(currency: Variables.Currency, force_NL: bool = False, company: bool = False) -> (str, str, str):
    if currency == Variables.Currency.EUR or force_NL:
        if np.random.rand() < 0.8 or force_NL:
            faker_ = Variables.get_faker_from_locale(Variables.currency_to_locale_dict["nl"])
            return faker_.address(), "NL", _generate_name(faker_, company)
        else:
            info = random.choice(Variables.additional_EURO_countries_and_faker)
            return info[1].address(), info[0], _generate_name(info[1], company)
    else:
        faker_ = Variables.get_faker_from_locale(Variables.currency_to_locale_dict[currency])
        return faker_.address(), Variables.currency_to_country[currency], _generate_name(faker_, company)


def _generate_name(faker_: Faker, company: bool) -> str:
    return faker_.company() if company else faker_.name()


def generate_random_8_4_4_4_12() -> str:
    return Variables.uuid_faker.uuid4()


def generate_random_string_letters(length: int = 10) -> str:
    characters = string.ascii_letters
    return ''.join(random.choice(characters) for _ in range(length))
