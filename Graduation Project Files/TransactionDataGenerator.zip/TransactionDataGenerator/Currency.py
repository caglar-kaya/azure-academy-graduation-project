from enum import Enum


class Currency(Enum):
    EUR = "EUR",
    GBP = "GBP",
    CAD = "CAD",
    USD = "USD",
    JPY = "JPY"
