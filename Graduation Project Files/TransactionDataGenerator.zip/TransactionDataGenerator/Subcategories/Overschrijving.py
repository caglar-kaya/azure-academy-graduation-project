from Client import Client
from Subcategories.SubCategory import SubCategory


class Overschrijving(SubCategory):
    name = "Overschrijving"

    def generate_description(self, counterParty: Client) -> str:
        return f"{self.name}: {counterParty.Name}"
