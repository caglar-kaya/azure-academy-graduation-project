import random
import numpy as np
from Client import Client
from Transaction import Transaction


# AGE GROUPS:
# [6-16, 16-24, 24-32, 32-55, 55-65, 65-]
class Customer():
    def __init__(self, client_data: Client, age_group: int, income: float, housing_cost: float, spend_ratio: float,
                 balance: float, employer: Client):
        self.Client = client_data
        self.Age_group = age_group
        self.Income = income
        self.Housing_cost = housing_cost
        self.__original_spend_ratio = spend_ratio
        self.Spend_ratio = spend_ratio
        self.Balance = balance
        self.Original_balance = balance
        self.Payday = random.choice([1, 2, 3, 20, 21, 22, 23, 24, 25, 26, 27])
        self.Employer = employer

        self.transactions = []

    def update_balance(self, amount: float) -> None:
        old_balance = self.Balance
        self.Balance -= amount
        if self.Balance < -2000 < old_balance:
            self.Spend_ratio = 0.6 * self.__original_spend_ratio
        elif self.Balance < -500 < old_balance:
            self.Spend_ratio = 0.7 * self.__original_spend_ratio
        if self.Balance < -200 and self.Spend_ratio == self.__original_spend_ratio:
            self.Spend_ratio = 0.8 * self.__original_spend_ratio
        if old_balance < 0 < self.Balance:
            self.Spend_ratio = 0.9 * self.__original_spend_ratio
        elif old_balance < 500 < self.Balance:
            self.Spend_ratio = self.__original_spend_ratio

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def compute_total_emissions(self) -> float:
        sum_ = 0
        for trans in self.transactions:
            sum_ += trans.emissions
        return sum_


def generate_random_batch_customers(count) -> list:
    ans = []
    incomes = [
        (100, 40, 200),
        (400, 250, 3000),
        (2000, 500, 14000),
        (3000, 900, 22000),
        (3500, 1000, 28000),
        (2200, 800, 10000)
    ]
    housing_cost = [
        (0, 0, 0),
        (200, 150, 1000),
        (1000, 300, 3000),
        (1200, 400, 4000),
        (1300, 500, 5000),
        (400, 250, 2000)
    ]
    for i in range(0, count):
        age_group = np.random.randint(0, len(incomes))
        values_to_use = incomes[age_group]
        inc = max(min(np.random.normal(values_to_use[0], values_to_use[1]), values_to_use[2]), 0)

        housing_cost_values = housing_cost[age_group]
        house_cost = min(max(min(np.random.normal(housing_cost_values[0], housing_cost_values[1]), housing_cost_values[2]), 0),
                         0.9*inc)

        if house_cost > 0.9*inc:
            house_cost = 0.9 * inc

        spend_ratio = max(min(np.random.normal(0.9, 0.2), 1.4), 0.4)
        balance = np.random.randint(0, 10000)
        employer = Client.create_random_client(company=True)
        ans.append(Customer(Client.create_random_client(), age_group, int(inc), house_cost if inc > 0 else 0, spend_ratio, balance, employer))
    return ans
