import numpy as np

from Client import Client
from Subcategories.SubCategory import SubCategory


_tikkie_reasons = ["Boodschappen", "Biertje", "Taxi", "Uiteten", "Verrekening", "Cadeautje", "Treinkaartje",
                   "Glaasje Wijn", "Bus", "Benzine", "Metro", "Vakantie", "Donatie", "Overnachting"]


class Tikkie(SubCategory):
    name = "Tikkie"

    def generate_description(self, counterParty: Client) -> str:
        return f"{self.name}: {np.random.choice(_tikkie_reasons)}, {counterParty.Name}, {counterParty.IBAN}"
