import Variables
from Client import Client

import numpy as np

from Subcategories.DefinedSubcategories import sub_cats
from Subcategories.SubCategory import SubCategory


def _generate_sub_type(dtld_tx_tp: int) -> SubCategory:
    options = sub_cats[dtld_tx_tp]
    if len(options) > 1:
        probabilities = [t[0] for t in options]
        sub_cat_ = options[np.random.choice(len(options), 1, p=probabilities)[0]][1]
        return sub_cat_
    else:
        return options[0][1]


class Category():
    def __init__(self, dtld_tx_tp: int, mean: float, sigma: float, age_multipliers: list, crdt_dbt: str = "CRDT"):
        self.dtld_tx_tp = dtld_tx_tp
        self.mean = mean
        self.sigma = sigma
        self.age_multipliers = age_multipliers
        self.clients = self._generate_list_of_clients()
        self.crdt_dbt = crdt_dbt
        self.sub_type = _generate_sub_type(dtld_tx_tp)

    def generate_amount(self, age_group: int) -> float:
        if self.age_multipliers[age_group] == 0:
            return 0
        return round(max(0, np.random.normal(self.age_multipliers[age_group] * self.mean, self.age_multipliers[age_group] * self.sigma)),2)

    def _generate_list_of_clients(self) -> list:
        if self.dtld_tx_tp == 3333:
            return [Client.create_random_client(company=False) for _ in range(0, Variables.clients_per_category)]
        elif self.dtld_tx_tp == 1111:
            prob_human = max(min(np.random.normal(0.08, 0.02), 0.5), 0.0)
            humans = int(Variables.clients_per_category * prob_human)
            companies = Variables.clients_per_category - humans
            return [Client.create_random_client(company=True) for _ in range(0, companies)] + \
                [Client.create_random_client(company=False) for _ in range(0, humans)]
        else:
            return [Client.create_random_client(company=True) for _ in range(0, Variables.clients_per_category)]


current_categories = [
    Category(5411, 40, 20, [0, 1, 1.5, 2, 1.5, 1.5]),
    Category(5420, 25, 5, [0, 0.5, 1, 2, 2.2, 1.5]),
    Category(5462, 10, 20, [0.5, 0.5, 1, 2, 2.5, 2.5]),
    Category(5422, 10, 3, [0, 0.5, 1, 2, 1.5, 1.5]),
    Category(5912, 10, 5, [0, 3, 2, 1, 1.5, 1.6]),
    Category(4131, 10, 5, [0.5, 1, 1.5, 0.5, 0.5, 1.1]),
    Category(4111, 8, 4, [0.5, 1, 1.5, 0.5, 0.5, 1.1]),
    Category(4112, 50, 20, [0, 1, 2, 2, 1.5, 0.5]),
    Category(5541, 40, 20, [0, 0.5, 1, 2, 2, 1]),
    Category(5542, 40, 20, [0, 0.5, 1, 2, 2, 1]),
    Category(4511, 300, 150, [0, 1.2, 2, 2, 3, 0.3]),
    Category(7512, 100, 40, [0, 0, 1, 0.5, 0.3, 0.1]),
    Category(4121, 50, 20, [0, 0, 1, 0.2, 1.2, 2]),
    Category(6542, 200, 100, [0, 0.5, 1, 2, 1.5, 1.5]),
    Category(6630, 30, 12, [0, 0.5, 1, 2, 1.2, 1.3]),
    Category(3333, 40, 25, [1, 2, 2.2, 1.2, 0.7, 0.2]),
    Category(2222, 50, 50, [1, 0.3, 0.3, 1.5, 2, 3])
]

